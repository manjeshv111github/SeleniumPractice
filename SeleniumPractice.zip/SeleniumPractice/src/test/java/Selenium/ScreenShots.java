package Selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import com.google.common.io.Files;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class ScreenShots {
	
	

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.orangehrm.com/");
		driver.manage().window().maximize();
		
		File file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		Files.copy(file, new File("C:\\Users\\ManjeshaV\\Downloads\\ScreenShots\\Firstss.png"));
		
		//taking screenshot for perticular element
		
		WebElement ele = driver.findElement(By.xpath("//a[@href='/en/book-a-free-demo/']//following::button[.='Book a Free Demo' and @class='btn btn-ohrm btn-contact-sales']"));
		File file2=ele.getScreenshotAs(OutputType.FILE);
		Files.copy(file2, new File("C:\\Users\\ManjeshaV\\Downloads\\ScreenShots\\Firstss.png"));
		
		
		
		
	}

}
