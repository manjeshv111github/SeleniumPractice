package Selenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Frames {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.guru99.com/test/guru99home/");
		driver.manage().window().maximize();
		
		//Get total number of frames
		int i=driver.findElements(By.tagName("iframe")).size();
		System.out.println("Number of Frames "+i);
		
		//switching to frame, here we can use index,name or webelement
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@name='a077aa5e']")));
		
		driver.findElement(By.xpath("//img[@src='Jmeter720.png']")).click();
		
		//once execution is done it goes back to outside of the frame
		driver.switchTo().defaultContent();
		

	}

}
