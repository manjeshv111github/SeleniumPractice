package Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import dev.failsafe.internal.util.Durations;

public class ActionClass {

	// have to use 'perform' only if one action is there ex: just movetoelement.perform() or click.perform()
	// have to use 'build.perform' if we have multiple actions in a same line ex: movetoelement().click.build().perform()

	public static void moveToElement() {

		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://www.orangehrm.com/");
		
		
		Actions act = new Actions(driver);
		//act.moveToElement(driver.findElement(By.xpath("//a[.='Resources']"))).perform();
		act.moveToElement(driver.findElement(By.xpath("//img[@class='pe-2']"))).perform();

	}

	public static void moveToElement_Click() throws InterruptedException {

		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://www.orangehrm.com/");

		Actions act = new Actions(driver);
		// first movetoelement
		act.moveToElement(driver.findElement(By.xpath("//a[.='Resources']"))).perform();
		// now click on that element
		//act.moveToElement(driver.findElement(By.xpath("//div[@class='col-md-12 col-lg-12']//a[.='Blog']"))).click().build().perform();
		act.moveToElement(driver.findElement(By.xpath("//a[text()='Learn in Depth']"))).perform();
		Thread.sleep(5000);
		act.moveToElement(driver.findElement(By.xpath("//a[text()='HR's Guide to Effective Career Development']"))).perform();	
	}

	public static void keyBoardOperations() {

		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		// driver.get("https://tutorialsninja.com/demo/");
		driver.get("https://www.google.com");
		driver.findElement(By.name("q")).sendKeys("selenium");

		Actions act = new Actions(driver);
		// Keydowns multiple times
		act.moveToElement(driver.findElement(By.name("q"))).sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.DOWN)
				.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();

		driver.get("https://www.orangehrm.com/");
		driver.findElement(By.xpath(
				"//a[@href='/en/book-a-free-demo/']//following::button[.='Book a Free Demo' and @class='btn btn-ohrm btn-contact-sales']"))
				.click();

		driver.findElement(By.name("FullName")).sendKeys("Name");
		act.sendKeys(Keys.TAB);
		driver.findElement(By.name("Email")).sendKeys("Name@123.com");
		act.sendKeys(Keys.TAB);
		driver.findElement(By.name("CompanyName")).sendKeys("CmpyName");
		// act.sendKeys(Keys.TAB);

		Select drp = new Select(driver.findElement(By.xpath("//select[@name='Country']")));

		drp.selectByValue("India");

		driver.findElement(By.name("Contact")).sendKeys("0987654565");
		// act.sendKeys(Keys.TAB);
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='reCAPTCHA']")));
		driver.findElement(By.xpath("//span[@role='checkbox']")).click();
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//input[@value='Get a Free Demo']")).click();

	}

	public static void contextClick() {

		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://tutorialsninja.com/demo/");

		Actions act = new Actions(driver);

		// act.moveToElement(driver.findElement(By.xpath("//a[.='Components']"))).contextClick().build().perform();
		// or
		act.contextClick(driver.findElement(By.xpath("//a[.='Components']"))).build().perform();

	}

	public static void dragAndDrop() {

		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://jqueryui.com/droppable/");

		// driver.switchTo().frame("//iframe[@class='demo-frame']");
		driver.switchTo().frame(0);

		Actions act = new Actions(driver);
		act.clickAndHold(driver.findElement(By.xpath("//div[@id='draggable']")))
		.moveToElement(driver.findElement(By.xpath("//div[@id='droppable']"))).release().build().perform();

	}

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		// moveToElement();
		 moveToElement_Click();
		//keyBoardOperations();
		// contextClick();
		 //dragAndDrop();
		
	}

}
