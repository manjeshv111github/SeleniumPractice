package Selenium;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		driver.get("https://www.orangehrm.com/");
		driver.findElement(By.xpath("//a[@href='/en/book-a-free-demo/']//following::button[.='Book a Free Demo' and @class='btn btn-ohrm btn-contact-sales']")).click();
		
		/*driver.findElement(By.name("FullName")).sendKeys("Name");
		
		driver.findElement(By.name("Email")).sendKeys("Name@123.com");

		driver.findElement(By.name("CompanyName")).sendKeys("CmpyName");*/

		
		Select drp = new Select(driver.findElement(By.xpath("//select[@name='Country']")));
		
		//get all the values inside drpdown
		List<WebElement> str = drp.getOptions();
		
		str.size();
		
		for(WebElement ele:str) {
			
			String str1 = ele.getText();
			System.out.println(str1);
		}
		//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		
		drp.selectByIndex(4);
		drp.selectByValue("India");
		drp.selectByVisibleText("Zaire");
				
		/*driver.findElement(By.name("Contact")).sendKeys("0987654565");
		//act.sendKeys(Keys.TAB);
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='reCAPTCHA']")));
		driver.findElement(By.xpath("//span[@role='checkbox']")).click();
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//input[@value='Get a Free Demo']")).click();*/

	}

}
