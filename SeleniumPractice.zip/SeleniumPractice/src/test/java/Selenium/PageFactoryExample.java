package Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class PageFactoryExample {

	static WebDriver driver=null;

	@FindBy(xpath = "//input[@id='username']")
	WebElement txtUserName;

	@FindBy(xpath = "//input[@id='password']")
	WebElement txtPassword;

	@FindBy(xpath = "//button[.='Submit']")
	WebElement btnLogin;

	@Test
	public void launchURL() {	
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		driver = new ChromeDriver();
		PageFactory.initElements(driver, this);
		driver.get("https://practicetestautomation.com/practice-test-login/");
	}
	@Test
	public void enterUserName() {
		txtUserName.sendKeys("student");
	}
	@Test
	public void enterPassword() {
		txtPassword.sendKeys("Password123");
	}
	@Test
	public void clickLogin() {
		btnLogin.click();
	}
	
	public static void main(String[] args) {
		
		PageFactoryExample obj = new PageFactoryExample();
		obj.launchURL();
		obj.enterUserName();
		obj.enterPassword();
		obj.clickLogin();
		
	}

}
