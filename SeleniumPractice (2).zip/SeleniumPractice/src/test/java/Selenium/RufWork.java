package Selenium;

import java.time.Duration;
import java.util.Scanner;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RufWork {
	
	public static String randomeString()
	{
		String generatedstring=RandomStringUtils.randomAlphabetic(5);
		return generatedstring;
	}
	
	

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
				String str = randomeString();
				System.out.println(str.toUpperCase());
		//Using Path to setup drivers
		
		//how to get the project path		
		String projectPath = System.getProperty("user.dir");		
		//System.out.println(projectPath);
		
		//added this dependency as i was not able to launch any url and set the value 
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		
		//Edge Driver
		//System.setProperty("webdriver.edge.driver",projectPath+"/Drivers/EdgeDriver/msedgedriver.exe");
		//WebDriver driver = new EdgeDriver();
		
		//Chrome Driver
		System.setProperty("webdriver.chrome.driver",projectPath+"/Drivers/ChromeDriver/chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		//Using WebDriver Manager to setup drivers
		
		//chromedriver
		//WebDriverManager.chromedriver().setup(); 
		//WebDriver driver = new ChromeDriver();
				
		//Edge Driver
		//WebDriverManager.edgedriver().setup();
				
		//Firefox driver
		//WebDriverManager.firefoxdriver().setup();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.amazon.in/");
		
		System.out.println("Enter Captcha: ");
		Scanner s = new Scanner(System.in);
		String name = s.nextLine();
		System.out.println("Your username is " + name);
		
		driver.findElement(By.id("captchacharacters")).sendKeys(name);
		//Thread.sleep(3000);
		driver.findElement(By.className("a-button-text")).click();
		
		driver.manage().window().maximize();
		
		String str1 =driver.getTitle();
		
		System.out.println(str1);
		
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("ballpen");
		driver.findElement(By.id("nav-search-submit-button")).click();
		
		//Thread.sleep(3000);
		WebElement ele = driver.findElement(By.xpath("//span[text()='Reynolds JETTER CLASSIC Ball Pen SET - 20 PENS BLUE | MULTI BODY COLOR BALL PEN WITH COMFORTABLE GRIP |BLUE BALL PENS FOR WRITING | PEN FOR PROFESSIONALS | 0.7 mm TIP SIZE']//following::button[text()='Add to cart' and @id='a-autoid-60-announce']"));
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView()", ele);
		
		//this is to highlight the element after reaching there
		js.executeScript("arguments[0].setAttribute('style', 'background: blue; border: 2px solid red;');", ele);
		Thread.sleep(3000);
		
		
		driver.close();
		
		//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		
		//DropDown : we have use select constructor to access dropdown
		
		//driver.get("https://www.facebook.com");
		
		//driver.manage().window().maximize();
		
		//String strTittle =driver.getTitle();
		//String strCurrecntUrl = driver.getCurrentUrl();
		
		//System.out.println("Title of the page : "+strTittle);
		//System.out.println("Url of the page : "+strCurrecntUrl);
		
		//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		//For Higlighling the elements
		/*JavascriptExecutor js = (JavascriptExecutor) driver;
		
		WebElement ele =driver.findElement(By.xpath("//a[@role=\"button\" and @data-testid=\"open-registration-form-button\"]"));
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", ele);
		ele.click();*/
		//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		
		//Select drp = new Select(driver.findElement(By.name("birthday_day")));
		
        //use executeScript() method and pass the arguments 
        //Here i pass values based on css style. Yellow background color with solid red color border. 
	
		//drp.selectByIndex(10);
		
		
		
		
	

	}

}
