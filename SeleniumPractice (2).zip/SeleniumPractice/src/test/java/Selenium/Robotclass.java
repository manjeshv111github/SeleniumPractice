package Selenium;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Robotclass {

	public static void main(String[] args) throws AWTException, InterruptedException {
		// TODO Auto-generated method stub
		
		//will be use to handle the window popups key and mouse operations
		
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("mobile");
		
		/*driver.get("https://test.v1.incruiter.com/employer/login");
		driver.manage().window().maximize();
		
		driver.findElement(By.name("email")).sendKeys("itishree.samanta+pp@incruiter.com");
		driver.findElement(By.name("password")).sendKeys("Iti@123");
		driver.findElement(By.id("employer-login")).click();
		
		driver.findElement(By.xpath("//div[contains(text(),'IncVid')]//following::button[text()='Go to Dashboard'][1]")).click();
		driver.findElement(By.xpath("//a[text()='Interviews']")).click();
		driver.findElement(By.xpath("//img[@alt='filter-btn']")).click();
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement fb = driver.findElement(By.xpath("//div[text()='Experience']"));
		js.executeScript("arguments[0].scrollIntoView()", fb);
		
		//this is to highlight the element after reaching there
		//js.executeScript("arguments[0].setAttribute('style', 'background: blue; border: 2px solid red;');", fb);
		
		
		
		driver.findElement(By.xpath("//*[@id=\"rs-range-line\"]")).clear();
		
		Thread.sleep(3000);*/
		
		Robot robot = new Robot();
	
		/*robot.keyPress(KeyEvent.VK_DOWN);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_DOWN);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_ENTER);*/
		
		for(int i=0;i<=5;i++) {
			robot.keyPress(KeyEvent.VK_DOWN);
			Thread.sleep(2000);
		}

		robot.keyPress(KeyEvent.VK_ENTER);
	
	}

}
