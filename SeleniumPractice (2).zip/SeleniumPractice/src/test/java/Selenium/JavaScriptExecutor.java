package Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptExecutor {
	
	public static void scrollDown_Up() {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.orangehrm.com/");
		driver.manage().window().maximize();
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
	
		js.executeScript("window.scrollBy(0,2000)");	
		
		js.executeScript("window.scrollBy(0,-2000)");
		
	}
	
	public static void scrollToElement() throws InterruptedException {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.orangehrm.com/");
		driver.manage().window().maximize();
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement fb = driver.findElement(By.xpath("//img[@alt='facebook logo']"));
		js.executeScript("arguments[0].scrollIntoView()", fb);
		
		//this is to highlight the element after reaching there
		js.executeScript("arguments[0].setAttribute('style', 'background: blue; border: 2px solid red;');", fb);
		
		//after scroll to that element you can perform click operation
		//fb.click();
	}
	
	public static void scrollToElement_Click() {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.orangehrm.com/");
		driver.manage().window().maximize();
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement fb = driver.findElement(By.xpath("//img[@alt='facebook logo']"));
		
		//this is to highlight the element after reaching there
		js.executeScript("arguments[0].setAttribute('style', 'background: blue; border: 2px solid red;');", fb);
		
		js.executeScript("arguments[0].click()", fb);
		
	}
	
	public static void highlightElements() {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.orangehrm.com/");
		driver.manage().window().maximize();
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		//WebElement ele =driver.findElement(By.xpath("//a[@href='/en/book-a-free-demo/']//following::button[.='Book a Free Demo' and @class='btn btn-ohrm btn-contact-sales']"));
		WebElement ele =driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[1]/div/ul/li[1]/a/button"));
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", ele);
		ele.click();
		
	}
	

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//scrollDown_Up();
		scrollToElement();
		//scrollToElement_Click();
		//highlightElements();
	
	}

}
