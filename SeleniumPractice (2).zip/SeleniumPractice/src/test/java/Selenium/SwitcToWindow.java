package Selenium;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SwitcToWindow {

	static WebDriver driver;

	public static void getWindowHandle() {

		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		driver = new ChromeDriver();

		driver.get("https://www.orangehrm.com/");
		driver.manage().window().maximize();

		String parentWind = driver.getWindowHandle();
		System.out.println("Parent Window :" + parentWind);
	}

	public static void getWindowHandles() {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		driver = new ChromeDriver();

		driver.get("https://www.orangehrm.com/");
		String parentWind = driver.getWindowHandle();
		System.out.println("Parent window " + parentWind);
		driver.manage().window().maximize();

		// using javascript executor method for scolldown and clicking
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// scroll using some values here first 0-for horizantal scroll, 1000-for
		// vertical scroll
		// js.executeScript("window.scrollBy(0,1000)");
		
		//scroll to element
		// js.executeScript("arguments[0].scrollIntoView()", fb);
		
		//scroll to element and click
		//js.executeScript("arguments[0].click()", fb);
		WebElement fb = driver.findElement(By.xpath("//img[@alt='facebook logo']"));
		WebElement linkedln = driver.findElement(By.xpath("//img[@alt='linkedin logo']"));
		WebElement youTube = driver.findElement(By.xpath("//img[@alt='youtube logo']"));

		js.executeScript("arguments[0].click()", fb);
		js.executeScript("arguments[0].click()", linkedln);
		js.executeScript("arguments[0].click()", youTube);

		// fb.click();
		// driver.findElement(By.xpath("//img[@alt='linkedin logo']")).click();
		// driver.findElement(By.xpath("//img[@alt='youtube logo']")).click();

		Set<String> totalWindowsOpened = driver.getWindowHandles();
		int count = totalWindowsOpened.size();
		System.out.println(count);

		driver.switchTo().window(parentWind);

		// switching to the specific window
		for (String str : totalWindowsOpened) {

			String title = driver.switchTo().window(str).getTitle();
			System.out.println(title);
			if (title.contains("LinkedIn")) {
				driver.switchTo().window(str);// switch to the window
				driver.switchTo().window(str).close();// close window
				break;
			}
		}

	}

	public static void main(String[] args) {

		getWindowHandle();
		getWindowHandles();

	}

}
