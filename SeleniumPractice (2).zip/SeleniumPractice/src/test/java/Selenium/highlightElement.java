package Selenium;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class highlightElement {
	
	//this method is to highlight the elements
	public static void highlightElements(WebDriver driver,String name) throws IOException {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement ele=driver.findElement(By.xpath(name));
		js.executeScript("arguments[0].scrollIntoView()", ele);
		
		//this is to highlight the element after reaching there
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", ele);
	}
	
	//this method is to highlight the elements and Capture the screenshots both are combined
	public static void highlightAndCaptureSS(WebDriver driver,String name,String Description) throws IOException {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement ele=driver.findElement(By.xpath(name));
		js.executeScript("arguments[0].scrollIntoView()", ele);
		
		//this is to highlight the element after reaching there
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", ele);
		
		//to capture the screenshots
		ScreenShots.captureScreen(driver, Description);
	}
	
	public static void captureFailedScreen(WebDriver driver) throws IOException {
		String timeStamp = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		// Now you can do whatever you need to do with it, for example copy somewhere
		FileUtils.copyFile(scrFile, new File("C:\\Users\\ManjeshaV\\Downloads\\ScreenShots\\"+timeStamp+".png"));
		System.out.println("Failed ScreenShot is taken successfully.");
	}

}
