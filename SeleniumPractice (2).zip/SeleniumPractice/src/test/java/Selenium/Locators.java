package Selenium;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locators {
	
	
	public static void byXpath(WebDriver driver,String xpath) {
		
		driver.findElement(By.xpath(xpath));
		/*JavascriptExecutor js = (JavascriptExecutor)driver;
	
		js.executeScript("arguments[0].scrollIntoView()", driver.findElement(By.xpath(xpath)));
		
		//this is to highlight the element after reaching there
		js.executeScript("arguments[0].setAttribute('style', 'background: blue; border: 2px solid red;');", driver.findElement(By.xpath(xpath)));*/
		
	}
	
	public static void byName(WebDriver driver,String name) {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement ele=driver.findElement(By.xpath(name));
		js.executeScript("arguments[0].scrollIntoView()", ele);
		
		//this is to highlight the element after reaching there
		js.executeScript("arguments[0].setAttribute('style', 'background: blue; border: 2px solid red;');", ele);
		
	}
	
	public static void byId(WebDriver driver,String id) {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement ele=driver.findElement(By.xpath(id));
		js.executeScript("arguments[0].scrollIntoView()", ele);
		
		//this is to highlight the element after reaching there
		js.executeScript("arguments[0].setAttribute('style', 'background: blue; border: 2px solid red;');", ele);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.orangehrm.com/");
		driver.manage().window().maximize();
		
		//Name
		//driver.findElement(By.name("")).sendKeys("");
		
		//id
		//driver.findElement(By.id("")).sendKeys("");
		
		//Linktext
		//driver.findElement(By.linkText("Privacy Policy")).click();
		
		//partiallinktext
		//driver.findElement(By.partialLinkText("Privacy")).click();
		
		//className
		//driver.findElement(By.className("")).sendKeys("");
		
		//tagname
		//driver.findElement(By.tagName(""));
		
		//Xpath- starts-with
		//driver.findElement(By.xpath("//tagname[starts-with(@attribute,'starting value'"));
		
		//Contains
		//a[contains(text(),'Service')]
		//a[contains(@attributename,'value')]
		//a[contains(.,'value')]
		
		//text
		//a[@text='value'];
		
		//and or
		//a[@tagname='value' and @tagname='value']
		//a[@tagname='value' or @tagname='value']
		
		//parent
		//a[@tagname='value']//parent::parent tagname
		
		//child
		//a[@tagname='value']//child::child tagname
		
		//preceding
		//input[@name='Email']//preceding::div/child::input
		
		//following
		//input[@name='Email']//following::div/child::input
		
		

	}

}
