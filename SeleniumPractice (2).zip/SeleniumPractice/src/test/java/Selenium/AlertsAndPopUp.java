package Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertsAndPopUp {
	
	public static void alerts() throws InterruptedException {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().window().maximize();
		
		//Accept
		driver.findElement(By.xpath("//button[.='Click for JS Confirm']")).click();		
		String str =driver.switchTo().alert().getText();
		System.out.println(str);
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		System.out.println("Acepted");
		
		
		//Dismiss
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[.='Click for JS Confirm']")).click();
		Thread.sleep(5000);
		driver.switchTo().alert().dismiss();
		System.out.println("Dismissed");
		
		//Enter the Value into alert text box
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[.='Click for JS Prompt']")).click();
		Thread.sleep(5000);
		driver.switchTo().alert().sendKeys("ALERT BOX");
		driver.switchTo().alert().accept();
		System.out.println("Value entered as ALERT BOX");
				
	}
	
	public static void authenticationPopUp() {
		
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver", projectPath + "/Drivers/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//String URL = "https://username:passwrod@the-internet.herokuapp.com/basic_auth";
		
		String userName = "admin";
		String password = "admin";
		
		driver.get("https://"+userName+":"+password+"@the-internet.herokuapp.com/basic_auth");
		driver.manage().window().maximize();
		
		String str3=driver.getPageSource();
		if(str3.contains("Congratulations! You must have the proper credentials")) {
			System.out.println("Authentication SuccessFull");
		}else
		{
			System.out.println("Authentication Failed");
		}
		
		
		
	}

	public static void main(String[] args) throws InterruptedException {
		
		//alerts();
		//authenticationPopUp();
		authenticationPopUp();
		
	}

}
